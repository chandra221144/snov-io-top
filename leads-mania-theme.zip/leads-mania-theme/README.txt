LEADS MANIA — WORDPRESS THEME

INSTALLATION
1. In WordPress, go to Appearance > Themes > Add New > Upload Theme.
2. Upload leads-mania-theme.zip and activate it. Requires a self-hosted WordPress installation or a WordPress.com plan that permits custom themes.
3. On activation, the theme creates the Home, review, comparisons, pricing, alternatives, guides and trust pages if their slugs do not already exist. Existing pages with the same slugs are not overwritten. If your site already has a static front page, the theme does not change it. To use the new homepage, choose Settings > Reading > A static page > Home.
4. Go to Settings > Permalinks and save if links need refreshing. The homepage is provided by front-page.php; other generated page content is editable under Pages. Internal links and affiliate buttons in editable pages use [url:page-slug] and [affiliate:Button text]. The affiliate URL is set in functions.php.
5. This theme is intended for a new site; back up an existing site before activating. Deactivating the theme does not delete the created pages. Links and affiliate-button placeholders in page content require the theme while active.

BEFORE LAUNCH
- Add a real contact method to the Contact page and customize the About page.
- Privacy Policy is a draft, not legal advice. Customize for your actual site configuration and obtain legal review.
- Verify all product descriptions, pricing, plan terms and affiliate program terms against the providers. Add genuine firsthand testing only after doing it. No test, rating, price, or publish/update date is fabricated.
- Confirm whether affiliate disclosures and consent mechanisms satisfy your jurisdiction. The affiliate link is https://snov.io?fp_ref=mrck20 and is marked sponsored/nofollow/noopener.
- No signup or contact forms, analytics, external fonts, integrations, FAQ structured data, or SEO plugin are included. The theme provides page meta descriptions for its seeded pages; avoid duplicate descriptions if using an SEO plugin.
- This is an original design and does not use Snov.io branding or logos. The theme has not been tested in a live WordPress environment; test desktop, mobile, links, and theme compatibility before publishing.

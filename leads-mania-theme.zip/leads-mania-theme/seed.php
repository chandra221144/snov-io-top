<?php
if (!defined('ABSPATH')) exit;
function lm_seed_pages(){
 $data=json_decode(file_get_contents(get_template_directory().'/content.json'),true);
 foreach($data as $slug=>$item){
  $existing=get_page_by_path($slug);
  if($existing) { if($slug==='home') $home_id=$existing->ID; continue; }
  $id=wp_insert_post(array('post_type'=>'page','post_status'=>'publish','post_name'=>$slug,'post_title'=>$item[0],'post_content'=>$item[2]));
  if(!is_wp_error($id) && $id){ update_post_meta($id,'_lm_description',$item[1]); if($slug==='home') $home_id=$id; }
 }
 if(!empty($home_id) && get_option('show_on_front')!=='page'){ update_option('show_on_front','page'); update_option('page_on_front',$home_id); }
}
add_filter('the_content',function($content){
 $content=preg_replace_callback('/\[url:([a-z0-9-]+)\]/',function($m){ return lm_url($m[1]); },$content);
 $content=preg_replace_callback('/\[affiliate:([^\]]+)\]/',function($m){ return lm_button($m[1]); },$content);
 return $content;
}, 9);

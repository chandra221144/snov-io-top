<?php
if (!defined('ABSPATH')) exit;
add_action('after_setup_theme', function(){ add_theme_support('title-tag'); add_theme_support('automatic-feed-links'); add_theme_support('responsive-embeds'); });
add_action('wp_enqueue_scripts', function(){ wp_enqueue_style('leads-mania', get_stylesheet_uri(), array(), '1.0'); });
function lm_url($slug=''){ return esc_url(home_url('/'.trim($slug,'/').($slug ? '/' : ''))); }
function lm_affiliate(){ return 'https://snov.io?fp_ref=mrck20'; }
function lm_button($label='Try Snov.io Free'){ return '<a class="button" href="'.esc_url(lm_affiliate()).'" target="_blank" rel="sponsored nofollow noopener">'.esc_html($label).' <span aria-hidden="true">↗</span></a>'; }
add_action('wp_head',function(){ if(is_singular()){ $p=get_queried_object(); $desc=get_post_meta($p->ID,'_lm_description',true); if($desc) echo '<meta name="description" content="'.esc_attr($desc).'">' . "\n"; } });
require_once get_template_directory().'/seed.php';
add_action('after_switch_theme','lm_seed_pages');

LEADS MANIA — STATIC WEBSITE
============================

This folder is a complete, ready-to-host website. 17 pages, no database,
no PHP, no build step needed on the server.


STEP 1 — SET YOUR DOMAIN (do this first, it takes 10 seconds)
-------------------------------------------------------------
Open a terminal in this folder and run:

    ./set-domain.sh https://yourdomain.com

(Replace with your real domain, including https://)

This rewrites the canonical tags, og:url tags, sitemap.xml and robots.txt so
they point at your domain instead of the placeholder.

Skipping this step means Google sees "https://YOUR-DOMAIN.com" in your
canonical tags and will not index your real pages. Do not skip it.

On Windows without bash: open index.html, sitemap.xml, robots.txt and every
folder's index.html, and replace the text  https://YOUR-DOMAIN.com  with your
own domain. Or just ask me and I'll rebuild it with your domain baked in.


STEP 2 — UPLOAD
---------------
Upload the CONTENTS of this folder into your web root (often public_html,
www, or htdocs). Not the folder itself — its contents.

Works on any static host:
  - Shared hosting / cPanel      -> File Manager, upload into public_html
  - Netlify    -> drag this folder onto app.netlify.com/drop
  - Vercel     -> vercel deploy, framework preset: Other
  - GitHub Pages -> push contents to the repo, enable Pages
  - Cloudflare Pages -> upload, no build command


STEP 3 — CHECK
--------------
Visit these and confirm they load:

    /                        home
    /snov-io-review/         review
    /snov-io-pricing/        pricing
    /sitemap.xml             sitemap
    /style.css               stylesheet

Then submit  https://yourdomain.com/sitemap.xml  in Google Search Console.


FILES
-----
index.html                     homepage
<sections>/index.html          16 section pages
style.css                      all styling
figures/*.svg                  5 explainer diagrams
og-image.png                   1200x630 social sharing card
sitemap.xml                    17 URLs
robots.txt                     allows crawling, points to sitemap
.htaccess                      directory indexes, caching, compression (Apache)
_headers                       cache + security headers (Netlify/Cloudflare)
404.html                       friendly not-found page
set-domain.sh                  domain setter (see step 1)

.html, .css and .svg files are gzipped automatically by most hosts. Total
size before compression is under 2 MB, dominated by og-image.png (745 KB).


BEFORE YOU GO LIVE — PLEASE FIX THESE
-------------------------------------
1. CONTACT PAGE HAS A PLACEHOLDER instead of a real email or form. A dead
   contact method damages trust and is the one thing readers will notice.
2. PRIVACY POLICY IS A DRAFT, not legal advice. Have it reviewed for your
   actual hosting, analytics and affiliate setup.
3. ALL PRICES ARE APPROXIMATE RANGES compiled from third-party sources.
   Re-check them against the providers before launch, then quarterly.
4. Replace og-image.png if you rebrand. Keep it 1200x630.
5. No analytics is installed. Add one (prefer a cookie-light option) so you
   can actually measure what Search Console shows you.

Deliberately NOT included: fake product screenshots, star ratings, or
invented tests. The site states it is research-based, so it must stay that
way. See /how-we-research/ for the promise you are publishing.
